@echo off
setlocal enabledelayedexpansion

cd /d "%~dp0"
title Система защиты и анализа
chcp 65001 >nul

set "report_file=scan_report.txt"
:: Для теста лучше начать с рабочего стола, чтобы проверить работу
set "target_dir=%USERPROFILE%\Desktop"

echo Инициализация...
echo ================================================== > "%report_file%"
echo           ОТЧЕТ О БЕЗОПАСНОСТИ СИСТЕМЫ           >> "%report_file%"
echo ================================================== >> "%report_file%"


echo [1/3] Сбор системных данных...
tasklist /NH >> "%report_file%" 2>nul
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" >> "%report_file%" 2>nul

echo [2/3] Поиск подозрительных файлов на Рабочем столе...
echo Пожалуйста, подождите...


set "pats=powershell -enc bypass hidden rmdir taskkill Cookies Login Data"

for /r "%target_dir%" %%f in (*.bat *.vbs *.ps1 *.txt) do (
    if /i "%%~nxf" neq "%report_file%" (
        for %%p in (%pats%) do (
            findstr /i /c:"%%p" "%%f" >nul
            if !errorlevel! == 0 (
                echo.
                echo [!!!] НАЙДЕНО: %%~nxf
                echo Путь: %%f
                echo Признак: %%p
                
                set /p "ans=Удалить этот файл? (Y - Да / N - Нет): "
                if /i "!ans!"=="Y" (
                    del /f /q "%%f"
                    echo [ОК] Удалено.
                    echo [УДАЛЕНО]: %%f >> "%report_file%"
                ) else (
                    echo [!] Пропущено.
                    echo [ПРОПУЩЕНО]: %%f >> "%report_file%"
                )
            )
        )
    )
)

echo.
echo ==================================================
echo [3/3] ГОТОВО! Проверьте файл: %report_file%
echo ==================================================
echo.
echo СОВЕТЫ ПО БЕЗОПАСНОСТИ:
echo 1. Не запускайте файлы от незнакомых людей.
echo 2. Проверяйте расширения (опасно: .exe.bat, .scr).
echo 3. Если файл просит отключить антивирус - это вирус.
echo -------------------------------------------------- >> "%report_file%"
echo СОВЕТ: Всегда проверяйте файлы через VirusTotal.com >> "%report_file%"

pause
