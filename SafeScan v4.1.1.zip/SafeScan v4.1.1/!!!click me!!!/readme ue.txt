========================================================================
             DOCUMENTATION & SECURITY PASSPORT: SafeScan v4.0
========================================================================

1. SOFTWARE PURPOSE
This script (SafeScan.bat) is designed to perform a primary security 
audit of the Windows operating system. The main objective is to 
identify traces of malicious activity within script files and 
system processes.

2. SECURITY DECLARATION (ANTI-MALWARE)
The developer officially declares that this software code:
- IS NOT a Stealer: it does NOT collect passwords, cookies, or autofill data.
- IS NOT a Winlocker: it does NOT restrict access to the operating system.
- IS NOT a RAT (Remote Access Trojan): it does NOT contain remote control features.
- HAS NO network capabilities (no data exchange or "phone home" commands).

The entire source code is OPEN SOURCE. You can verify every line by 
right-clicking the .bat file and selecting "Edit".

3. OPERATIONAL PRINCIPLES (ALGORITHM)
The script performs a three-stage security analysis:
   3.1. Process Audit: Generates a list of all active tasks (Tasklist).
   3.2. Startup Audit: Scans Registry hives (HKCU/HKLM) for 
        unauthorized software auto-start entries.
   3.3. Signature File Analysis: Searches for specific obfuscation and 
        malicious commands (Base64, Hidden, Bypass) in .bat, .vbs, .ps1, 
        and .txt file formats.

4. USER INSTRUCTIONS
- Execution: Running as Administrator is recommended to allow the 
  script to analyze system-level Registry branches.
- Threat Handling: Upon detecting suspicious code, the script PAUSES 
  and requests user confirmation for deletion (Y/N). 
  The final decision always rests with the operator.
- Reporting: All results are automatically saved to the "logs" 
  directory in a structured text file format.

5. FALSE POSITIVE WARNING
The script utilizes a heuristic analysis method. Files containing 
legitimate administrative commands (e.g., rmdir or taskkill) may be 
flagged as "suspicious". Carefully review the file path and its 
intended purpose before confirming deletion.

------------------------------------------------------------------------
SafeScan — A Transparent Diagnostic Tool. Your security is in your hands.
========================================================================
