@echo off
setlocal enabledelayedexpansion
title Love Message
chcp 65001 >nul

:loop
:: Розовый/Красный цвет (Color 0D)
color 0D
cls
echo.
echo       ***     ***
echo      *****   *****
echo     ******* *******
echo      *************
echo       ***********
echo        *********
echo         *******
echo          *****
echo           ***
echo            *
echo.
echo    penoraSearch loves you
timeout /t 1 >nul

:: Ярко-красный цвет (Color 0C)
color 0C
cls
echo.
echo       ***     ***
echo      *****   *****
echo     ******* *******
echo      *************
echo       ***********
echo        *********
echo         *******
echo          *****
echo           ***
echo            *
echo.
echo    penoraSearch loves you
timeout /t 1 >nul

goto loop
