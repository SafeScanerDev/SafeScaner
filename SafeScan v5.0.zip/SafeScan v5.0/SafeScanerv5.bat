@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title SafeScaner v5.5 - Pure Logs Edition
chcp 65001 >nul


set "log_dir=logs"
if not exist "%log_dir%" mkdir "%log_dir%"
set "report_file=%log_dir%\scan_report_%random%.txt"
set "temp_list=%temp%\safescan_list.txt"
if exist "%temp_list%" del /f /q "%temp_list%"

set "target=%USERPROFILE%\Desktop"


echo ========================================== > "%report_file%"
echo    СПИСОК ОБНАРУЖЕННЫХ УГРОЗ (SafeScaner) >> "%report_file%"
echo ========================================== >> "%report_file%"
echo Время сканирования: %date% %time% >> "%report_file%"
echo. >> "%report_file%"

echo [!] Идет поиск... Это не займет много времени.
echo.

set "pats=powershell bypass hidden rmdir taskkill Cookies Login Data net-user bitsadmin"
set "found_count=0"


for /r "%target%" %%f in (*.bat *.vbs *.ps1 *.txt *.cmd) do (
    echo "%%f" | findstr /i "logs" >nul
    if errorlevel 1 (
        set "match=0"
        for %%p in (%pats%) do (
            if "!match!"=="0" (
                findstr /i /c:"%%p" "%%f" >nul
                if !errorlevel! == 0 (
                    set "match=1"
                    set /a "found_count+=1"
                    
                    
                    set "reason=Подозрительный код"
                    if "%%p"=="powershell" set "reason=Запуск скриптов PowerShell"
                    if "%%p"=="bypass"     set "reason=Обход защитных политик"
                    if "%%p"=="hidden"     set "reason=Скрытый запуск (маскировка)"
                    if "%%p"=="rmdir"      set "reason=Команда удаления директорий"
                    if "%%p"=="taskkill"   set "reason=Попытка закрытия программ"
                    if "%%p"=="Cookies"    set "reason=Доступ к куки (Стиллер!)"
                    if "%%p"=="Login Data" set "reason=Доступ к паролям (Стиллер!)"
                    if "%%p"=="net-user"   set "reason=Управление аккаунтами"
                    if "%%p"=="bitsadmin"  set "reason=Фоновая загрузка из сети"

                    
                    echo [ОБЪЕКТ]: %%~nxf >> "%report_file%"
                    echo [ПРИЧИНА]: !reason! >> "%report_file%"
                    echo [ПУТЬ]: %%f >> "%report_file%"
                    echo -------------------------------------- >> "%report_file%"
                    
                    :: Сохраняем путь для удаления
                    echo %%f >> "%temp_list%"
                    
                    echo [+] Найдено: %%~nxf
                )
            )
        )
    )
)

:: --- ФИНАЛЬНЫЙ ЭКРАН ---
echo.
echo ==========================================
if %found_count% GTR 0 (
    echo СКАНИРОВАНИЕ ЗАВЕРШЕНО!
    echo Найдено угроз: %found_count%
    echo Детальный список и пути в файле: %report_file%
    echo.
    set /p "final_ans=УДАЛИТЬ ВСЕ НАЙДЕННЫЕ ОБЪЕКТЫ? (Y/N): "
    
    if /i "!final_ans!"=="Y" (
        echo [!] Очистка...
        for /f "usebackq delims=" %%i in ("%temp_list%") do (
            del /f /q "%%i" >nul 2>&1
            echo [X] Удален: %%~nxi
        )
        echo [OK] Все объекты стерты.
        echo. >> "%report_file%"
        echo СТАТУС: Все файлы выше были удалены пользователем. >> "%report_file%"
    ) else (
        echo [!] Удаление отменено. Файлы остались на месте.
        echo. >> "%report_file%"
        echo СТАТУС: Пользователь сохранил данные файлы. >> "%report_file%"
    )
) else (
    echo Угроз не обнаружено. Система чиста!
    echo [РЕЗУЛЬТАТ]: Угроз не найдено. >> "%report_file%"
)

:: Уборка
if exist "%temp_list%" del /f /q "%temp_list%"